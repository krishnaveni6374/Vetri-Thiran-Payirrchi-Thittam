# Auto Ticket Classification using Flow Designer

## Project Description
This project automates the classification of support tickets using Flow Designer. When a new ticket is created, the flow checks the ticket information and automatically assigns an appropriate category and priority.

## Objective
To reduce manual ticket classification and improve the speed and consistency of ticket routing.

## Tools Used
- ServiceNow
- Flow Designer
- ServiceNow Tables
- Business Rules / Flow Logic

## Workflow
1. A new ticket is created.
2. The Flow Designer flow is triggered.
3. Ticket details are checked.
4. Conditions are evaluated.
5. The ticket is classified automatically.
6. The appropriate category/priority is updated.

## Example
Ticket: "Unable to access my email"

Possible classification:
- Category: Email
- Priority: Medium

## Project Structure
- `Flow-Designer/` – Place exported Flow Designer files or flow documentation here.
- `Screenshots/` – Place screenshots of the flow and execution results here.
- `Documentation/` – Place project documentation here.

## Note
This repository is a project documentation/template package. Add your actual ServiceNow Flow Designer export files and screenshots before submitting or publishing the project.
